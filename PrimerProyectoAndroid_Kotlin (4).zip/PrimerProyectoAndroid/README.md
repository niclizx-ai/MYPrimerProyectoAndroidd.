# Mi primer proyecto Android

Proyecto de ejemplo desarrollado en **Kotlin y XML para Android Studio**. Incluye los tres requisitos de la actividad.

## Requisitos cubiertos

1. **Idiomas:** español predeterminado (`values`), inglés (`values-en`), francés (`values-fr`) y alemán (`values-de`). Android selecciona automáticamente los textos según el idioma configurado en el dispositivo.
2. **Fondo Nine-Patch:** `app/src/main/res/drawable-nodpi/fondo_android.9.png`. Los segmentos laterales y la zona superior son las áreas elásticas; la franja central inferior que contiene al marcianito se conserva para evitar deformarlo. El archivo original también se incluye como `fondo_android_original.png`.
3. **Múltiples pantallas:** se usa `ConstraintLayout` con posiciones relativas y una versión alternativa para orientación horizontal (`res/layout-land`). No se bloquea la orientación del dispositivo.

## Abrir y ejecutar

1. Descomprime el ZIP.
2. Abre Android Studio y selecciona **Open**.
3. Selecciona la carpeta `PrimerProyectoAndroid` (la que contiene `settings.gradle.kts`).
4. Espera a que Gradle sincronice el proyecto. Si Android Studio solicita instalar Android SDK 35, acepta la instalación.
5. Ejecuta la aplicación en un emulador o dispositivo Android.

## Comprobar los cuatro idiomas

Cambia el idioma del emulador o del dispositivo desde los ajustes del sistema y vuelve a abrir la aplicación. Prueba español, inglés, francés y alemán. Los textos de título, botón, mensaje y nombre de aplicación tienen sus traducciones.

## Comprobar tamaños y orientación

Ejecuta la aplicación en un teléfono y una tableta, primero en vertical y luego en horizontal. La carpeta `layout-land` proporciona una distribución específica para orientación horizontal.

## Nota técnica sobre Nine-Patch

El formato `.9.png` utiliza un borde de un píxel para indicar las zonas que Android puede estirar. En este proyecto se dejan fijas las áreas centrales donde está el personaje y se permite el estiramiento en los laterales y en el cielo superior. Android procesa las guías al compilar los recursos. No elimines el borde de un píxel ni renombres el archivo quitando `.9`.

## Componentes principales

- `MainActivity.kt`: carga la interfaz y da respuesta al botón.
- `activity_main.xml`: distribución vertical.
- `layout-land/activity_main.xml`: distribución horizontal.
- `values*/strings.xml`: traducciones.
- `drawable-nodpi/fondo_android.9.png`: fondo Nine-Patch.
