plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.primerproyectoandroid"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.primerproyectoandroid"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}


dependencies {
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
}
