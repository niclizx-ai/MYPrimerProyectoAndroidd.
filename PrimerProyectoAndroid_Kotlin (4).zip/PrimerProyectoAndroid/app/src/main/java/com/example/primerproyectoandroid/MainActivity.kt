package com.example.primerproyectoandroid

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = getColor(R.color.status_bar)
        window.navigationBarColor = getColor(R.color.navigation_bar)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.enterButton).setOnClickListener {
            Toast.makeText(this, getString(R.string.welcome_message), Toast.LENGTH_SHORT).show()
        }
    }
}
